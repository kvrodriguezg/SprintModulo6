package FullStackJava.Modulo6_KRodriguez.Modelo.DAO;

import java.util.List;

import FullStackJava.Modulo6_KRodriguez.Modelo.bean.Chequeo;

public interface IChequeoServicio {
	
	public List<Chequeo> obtenerChequeos();

}

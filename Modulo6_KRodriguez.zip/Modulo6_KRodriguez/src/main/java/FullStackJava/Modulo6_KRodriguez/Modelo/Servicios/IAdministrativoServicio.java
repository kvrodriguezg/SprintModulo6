package FullStackJava.Modulo6_KRodriguez.Modelo.Servicios;

import FullStackJava.Modulo6_KRodriguez.Modelo.bean.Administrativo;

public interface IAdministrativoServicio {

	public void editarAdmin(Administrativo us);
}

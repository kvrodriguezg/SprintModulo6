package FullStackJava.Modulo6_KRodriguez.Modelo.DAO;

import FullStackJava.Modulo6_KRodriguez.Modelo.bean.Administrativo;


public interface IAdministrativoDAO {

	public void editar(Administrativo admin); 
}

package FullStackJava.Modulo6_KRodriguez.Modelo.Servicios;

import FullStackJava.Modulo6_KRodriguez.Modelo.bean.Contacto;

public interface IContactoServicio {

	public void Ingreso_Contacto(Contacto cont);
}
